package com.nexora.souls;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class NexoraSouls extends JavaPlugin implements Listener {

    private final Map<UUID, Integer> soulsMap = new HashMap<>();
    private File dataFile;
    private FileConfiguration dataConfig;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        createDataFile();
        loadSouls();

        getServer().getPluginManager().registerEvents(this, this);

        if (getCommand("almas") != null) {
            getCommand("almas").setExecutor((sender, command, label, args) -> {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("Apenas jogadores podem usar este comando.");
                    return true;
                }

                Player player = (Player) sender;
                int souls = getSouls(player.getUniqueId());
                String prefix = color(getConfig().getString(
                        "messages.prefix", "&8[&bNexoraSouls&8] &7"));
                String msg = getConfig().getString(
                        "messages.balance", "&fVocê possui &b{souls} &falmas.");
                msg = msg.replace("{souls}", String.valueOf(souls));
                player.sendMessage(prefix + color(msg));
                return true;
            });
        }

        getLogger().info("NexoraSouls habilitado com sucesso!");
    }

    @Override
    public void onDisable() {
        if (dataConfig != null && dataFile != null) {
            saveSouls();
        }
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void createDataFile() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try {
                if (dataFile.getParentFile() != null) {
                    dataFile.getParentFile().mkdirs();
                }
                dataFile.createNewFile();
            } catch (IOException e) {
                getLogger().severe("Não foi possível criar o arquivo data.yml: " + e.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void loadSouls() {
        if (dataConfig == null || !dataConfig.isConfigurationSection("souls")) {
            return;
        }

        for (String key : dataConfig.getConfigurationSection("souls").getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                int souls = Math.max(0, dataConfig.getInt("souls." + key, 0));
                soulsMap.put(uuid, souls);
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("UUID inválido ignorado em data.yml: " + key);
            }
        }
    }

    private void saveSouls() {
        if (dataConfig == null || dataFile == null) {
            return;
        }

        for (Map.Entry<UUID, Integer> entry : soulsMap.entrySet()) {
            dataConfig.set("souls." + entry.getKey(), entry.getValue());
        }

        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Erro ao salvar as almas no arquivo data.yml: " + e.getMessage());
        }
    }

    public int getSouls(UUID uuid) {
        return soulsMap.getOrDefault(uuid, 0);
    }

    public void setSouls(UUID uuid, int amount) {
        soulsMap.put(uuid, Math.max(0, amount));
        saveSouls();
    }

    public void addSouls(UUID uuid, int amount) {
        if (amount > 0) {
            setSouls(uuid, getSouls(uuid) + amount);
        }
    }

    public void removeSouls(UUID uuid, int amount) {
        if (amount > 0) {
            setSouls(uuid, getSouls(uuid) - amount);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null || killer.equals(victim)) {
            return;
        }

        UUID victimId = victim.getUniqueId();
        UUID killerId = killer.getUniqueId();

        int victimSouls = getSouls(victimId);
        double percentage = getConfig().getDouble(
                "settings.pvp-soul-transfer-percentage", 50.0);
        percentage = Math.max(0.0, Math.min(100.0, percentage));

        int transferAmount = (int) Math.round(victimSouls * (percentage / 100.0));
        if (transferAmount <= 0) {
            return;
        }

        removeSouls(victimId, transferAmount);
        addSouls(killerId, transferAmount);

        String prefix = color(getConfig().getString(
                "messages.prefix", "&8[&bNexoraSouls&8] &7"));

        String lossMsg = getConfig().getString(
                "messages.pvp-loss",
                "&cVocê perdeu &4{souls} &calmas ao morrer para &e{killer}&c!");
        lossMsg = lossMsg.replace("{souls}", String.valueOf(transferAmount))
                .replace("{killer}", killer.getName());
        victim.sendMessage(prefix + color(lossMsg));

        String gainMsg = getConfig().getString(
                "messages.pvp-gain",
                "&aVocê saqueou &2{souls} &aalmas de &e{victim}&a!");
        gainMsg = gainMsg.replace("{souls}", String.valueOf(transferAmount))
                .replace("{victim}", victim.getName());
        killer.sendMessage(prefix + color(gainMsg));
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        Player killer = entity.getKiller();

        if (killer == null) {
            return;
        }

        String entityType = entity.getType().name();
        int reward = getConfig().getInt("mob-rewards." + entityType, 0);

        if (reward <= 0) {
            return;
        }

        addSouls(killer.getUniqueId(), reward);

        String prefix = color(getConfig().getString(
                "messages.prefix", "&8[&bNexoraSouls&8] &7"));
        String msg = getConfig().getString(
                "messages.mob-reward",
                "&aVocê ganhou &2+{souls} &aalmas por eliminar um mob!");
        msg = msg.replace("{souls}", String.valueOf(reward));
        killer.sendMessage(prefix + color(msg));
    }
}
