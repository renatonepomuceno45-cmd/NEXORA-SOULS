NEXORASOULS - PROJETO MAVEN

ESTRUTURA
- pom.xml
- src/main/java/com/nexora/souls/NexoraSouls.java
- src/main/resources/config.yml
- src/main/resources/plugin.yml
- .github/workflows/build.yml

COMO USAR NO GITHUB PELO CELULAR
1. Extraia este ZIP no celular.
2. Crie um repositório vazio no GitHub.
3. Envie os ARQUIVOS E PASTAS que estão dentro da pasta NexoraSouls para a raiz do repositório.
   IMPORTANTE: não envie somente este ZIP como um arquivo; o GitHub precisa enxergar pom.xml na raiz.
4. Abra a aba Actions do repositório.
5. Se aparecer a opção, habilite workflows.
6. Execute "Compilar NexoraSouls" em Run workflow (ou faça um commit na branch main para disparar automaticamente).
7. Quando terminar, abra a execução concluída e baixe o artefato "NexoraSouls-JAR".
8. Extraia o artefato e pegue NexoraSouls-1.0.0.jar.

REQUISITOS
- GitHub Actions instala Java 21 e usa Maven na nuvem; não precisa instalar Maven no celular.
- O projeto usa Paper API 1.20.4.
- O JAR ainda precisa ser testado no servidor.

LIMITACOES DESTA VERSAO
- Inclui consulta /almas, recompensas configuradas por mobs e transferência de 50% das almas em mortes PvP.
- A loja aparece no config.yml, mas a lógica de compra ainda não foi implementada.
- Não há comandos administrativos para dar, retirar ou definir almas nesta versão.
